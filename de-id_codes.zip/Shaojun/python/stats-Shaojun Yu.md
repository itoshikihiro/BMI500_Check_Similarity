# Stats of deid-Shaojun Yu.py   
### Examining "Age" category.  
Num of true positives = 4

Num of false positives = 0

Num of false negatives = 0

Sensitivity/Recall = 1.0

PPV/Specificity = 1.0

---


### Examining "Phone" category. (improved)
Num of true positives = 43

Num of false positives = 2

Num of false negatives = 10

Sensitivity/Recall = 0.811

PPV/Specificity = 0.947

---

### Examining "Date" category.
Num of true positives = 173

Num of false positives = 115

Num of false negatives = 309

Sensitivity/Recall = 0.359

PPV/Specificity = 0.619

---


### Examining "PTName" category.
Num of true positives = 41

Num of false positives = 7

Num of false negatives = 13

Sensitivity/Recall = 0.759

PPV/Specificity = 0.854


---

### Examining "HCPName" category.
Num of true positives = 331

Num of false positives = 16

Num of false negatives = 262

Sensitivity/Recall = 0.558

PPV/Specificity = 0.954

---

### Examining "RelativeProxyName" category.
Num of true positives = 55

Num of false positives = 87

Num of false negatives = 120

Sensitivity/Recall = 0.314

PPV/Specificity = 0.412