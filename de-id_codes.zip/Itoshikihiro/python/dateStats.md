Examining "Date" category.


==========================

Num of true positives = 11

Num of false positives = 28

Num of false negatives = 471

Sensitivity/Recall = 0.023

PPV/Specificity = 0.3

==========================