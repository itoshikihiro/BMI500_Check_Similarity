
Examining "RelativeProxyName" category.


==========================

Num of true positives = 79

Num of false positives = 936

Num of false negatives = 96

Sensitivity/Recall = 0.451

PPV/Specificity = 0.757

==========================

Examining "PTName" category.


==========================

Num of true positives = 29

Num of false positives = 952

Num of false negatives = 25

Sensitivity/Recall = 0.537

PPV/Specificity = 0.752

==========================


Examining "HCPName" category.


==========================

Num of true positives = 119

Num of false positives = 924

Num of false negatives = 474

Sensitivity/Recall = 0.201

PPV/Specificity = 0.76

==========================


